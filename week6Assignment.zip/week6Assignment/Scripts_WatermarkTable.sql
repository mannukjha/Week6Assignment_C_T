-- Control table for incremental loading
CREATE TABLE WatermarkTable
(
    TableName VARCHAR(100),
    WatermarkColumn VARCHAR(100),
    WatermarkValue DATETIME,
    LastUpdated DATETIME DEFAULT GETDATE()
);

-- Initial record for your table
INSERT INTO WatermarkTable
VALUES ('YourSourceTable', 'ModifiedDate', '1900-01-01', GETDATE());