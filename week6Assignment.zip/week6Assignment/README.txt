AZURE DATA FACTORY INTEGRATION PACKAGE
--------------------------------------
This package contains all necessary components to:
1. Set up Self-Hosted Integration Runtime
2. Configure data pipelines for incremental loading
3. Schedule daily and monthly data transfers

INSTRUCTIONS:
1. Run the SHIR installation script on your on-premises server
2. Create the watermark table in your source database
3. Import all JSON files to Azure Data Factory
4. Configure connection strings with your actual credentials
5. Activate the triggers

For questions, contact: your.email@example.com