# Self-Hosted Integration Runtime Installation Script
$downloadUrl = "https://download.microsoft.com/download/E/4/6/E46.../IntegrationRuntime.msi"
$installPath = "$env:TEMP\IntegrationRuntime.msi"

# Download SHIR
Invoke-WebRequest -Uri $downloadUrl -OutFile $installPath

# Install with authentication key
Start-Process msiexec.exe -Wait -ArgumentList "/i $installPath /quiet /passive /norestart AUTH_KEY=your-auth-key-here"

# Verify service is running
Get-Service -Name "DIAHostService" | Select-Object Status, Name, DisplayName